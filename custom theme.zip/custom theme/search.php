 <?php
 get_header();
 ?> 
 
 
 <div class="wrap blog_wrap">
<h1 id = "search_heading">search results for <?php the_search_query();?></h1>
<?php get_template_part("include/section","archive");?>


    <div class="pagination">
	<?php previous_posts_link();?>
	<?php next_posts_link();?>  
    </div>

</div>
 <?php
 get_footer();
 ?>