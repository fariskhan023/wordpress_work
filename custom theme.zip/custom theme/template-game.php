<?php
/*
Template Name: game
*/
?> 


<?php
get_header();
?>
<div class = "wrap">
<h1><?php the_title();?></h1>

<h2>this is game template page</h2>
<iframe src="https://www.retrogames.cc/embed/9157-metal-slug-super-vehicle-001.html" width="600" height="450" frameborder="no" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" scrolling="no" style="margin-top:10px;margin-bottom:10px;"></iframe>


<?php get_template_part("include/section","content");?>
</div>
<?php
get_footer();
?>