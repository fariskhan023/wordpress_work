<?php
/*
Template Name: contact
*/
?> 

<?php get_header(); ?>
<div class = "wrap">
<h1><?php the_title();?></h1>
<?php get_template_part("include/section","content");?>
</div>
<?php get_footer();?> 