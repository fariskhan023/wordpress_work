<?php
get_header();
?> 
<div id ="main">
<?php
get_template_part("include/section","contentproductarchive");
?>
</div>
<?php
get_footer();
?>