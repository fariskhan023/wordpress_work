<?php
get_header();
?> 
<div class="wrap blog_wrap">

 <div class = "search_form">
<?php
get_search_form();
?>
</div>



<?php get_template_part("include/section","archive");?>


    <div class="pagination">
	<?php previous_posts_link();?>
	<?php next_posts_link();?>  
    </div>

</div>
<?php
get_footer();
?>