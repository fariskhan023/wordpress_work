<?php
if(have_posts()):
?>
<?php while(have_posts()):the_post();?>
<div class = "product_block">
<a href = "<?php the_permalink();?>">
<?php the_post_thumbnail();?>
<h2 class="product_title"><?php the_title();?></h2>
<h4 class = 'product_price'><?php echo wc_price(get_post_meta(get_the_ID(),'_price',true));?></h4>
</a>
</div>
<?php endwhile; ?>

<div class = "product_pagination">
<?php

 the_posts_pagination( array(
            'mid_size' => 2, // How many pages on either side of the current page
            'prev_text' => '&laquo; Prev', // Text for the "Previous" button
            'next_text' => 'Next &raquo;', // Text for the "Next" button
        ) );
?>
</div>

<?php else: ?>
<h1>no product found</h1>
<?php endif;?>