<?php
if(have_posts()):
?>
<?php while(have_posts()):the_post();?>
<div class = "product_block">
<a href = "<?php the_permalink();?>">
<?php the_post_thumbnail();?>
<h2 class="product_title"><?php the_title();?></h2>
<h4 class = 'product_price'><?php echo wc_price(get_post_meta(get_the_ID(),'_price',true));?></h4>
</a>
</div>
<?php endwhile; ?>
<?php else: ?>
<h1>no product found</h1>
<?php endif;?>