
 
 <?php
if( have_posts() ): 
while( have_posts() ):
the_post();
?>
<h1 id = "page_title"><?php the_title();?></h1>


<?php
if(has_post_thumbnail()):
?>
<img src = "<?php the_post_thumbnail_url("blog-small");?>" class="post_thumbnail">
<?php endif; ?>

<div class="blog_content_wrap">
<?php 
//the_content();
the_excerpt();
?>
<a href="<?php the_permalink();?>" target="blank" class="blog_readmore">read more</a>
</div>



<?php endwhile;else:endif;?>