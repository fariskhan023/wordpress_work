 <?php
if( have_posts() ): 
while( have_posts() ):
the_post();
?>

<h1 id = "page_title"><?php the_title();?></h1>

<?php
if(has_post_thumbnail()):
?>
<img src = "<?php the_post_thumbnail_url("blog-small");?>" class="post_thumbnail">
<?php endif; ?>

<?php the_content();?>
<span class = "posted">Posted by <?php the_author();?></span>
<span class = "posted">Posted date <?php the_date();?></span>


<span class = "post_tag">tags:&nbsp</span>
<?php
$tags = get_the_tags();
if(!empty($tags)):
foreach($tags as $tag):
?>

<a href = "<?php echo get_tag_link($tag->term_id);?>" class = "post_tag">
<?php echo $tag->name;?>
</a>

<?php endforeach;endif;?>

<div class = "comment">
<?php comments_template();?>
</div>
<?php endwhile;else:endif;?>