 <?php
 get_header();
 ?>
 
<div id = "main">

 <?php
	if(have_posts()):
 ?>
 <?php while(have_posts()):the_post();?>
 


<div class="product_image">
       
<?php
	   do_action( 'woocommerce_before_single_product_summary' ); // Image, gallery, etc.
        ?>
		</div>

 
 <div class = "product_single_content">
 <h1 class="product_title"><?php the_title();?></h1>
<h4 class = 'product_price'><?php echo wc_price(get_post_meta(get_the_ID(),'_price',true));?></h4>
<p class = "product_description">

<?php the_content();?>
</p>

<div class = "cart_button">
<?php woocommerce_template_single_add_to_cart();?>
</div>

</div>

<?php
endwhile;
?>
<?php
endif;
?> 

</div>

 <?php
 get_footer();
 ?>