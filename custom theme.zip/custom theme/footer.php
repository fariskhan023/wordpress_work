


<i class="fas fa-arrow-up page_up" id = "scrollup" onclick="scrolltotop()"></i>
<?php wp_footer();?>
</body>
</html> 