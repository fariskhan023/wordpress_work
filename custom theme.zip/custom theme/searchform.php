 <form>
 <label for = "search">search</label>
 <input type = "text" name = "s" id="search" value="<?php the_search_query();?>" required>
 <button type = "submit">search</button>
 </form>