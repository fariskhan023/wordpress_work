<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>document</title>
<?php wp_head();?>
</head>
<body>
<header id = "main_header">
<?php
wp_nav_menu(
array(
"theme_location" => "top-menu",
"menu_class" => "top-bar",
)
);
?>
</header>