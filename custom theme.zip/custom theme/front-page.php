<?php get_header(); ?>

<div class="wrap">
<div class = "search_form">
<?php
get_search_form();
?>
</div>
<h1 id = "page_title"><?php the_title();?></h1>
<?php get_template_part("include/section","content");?>
</div>
<?php get_footer();?> 