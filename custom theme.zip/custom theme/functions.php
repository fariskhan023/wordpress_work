 <?php
 function load_css()
 {
	 wp_register_style("customcss",get_template_directory_uri().'/css/style.css',array(),false,"all");
	 wp_enqueue_style("customcss");

  wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
 
 }
 add_action("wp_enqueue_scripts","load_css");
 
 function load_js()
 {
	 wp_enqueue_script("jquery");
	 wp_register_script("customjs",get_template_directory_uri()."/js/script.js",false,true);
	 wp_enqueue_script("customjs");
 }
 add_action("wp_enqueue_scripts","load_js");
 
 //theme option
 add_theme_support("menus");
 add_theme_support("post-thumbnails");
 add_theme_support("widgets");
 
 //menu
 register_nav_menus(
 array(
 "top-menu" => "top menu location",
 "mobile-menu" => "mobile menu location",
 )
 );
 
 //custom image size
 add_image_size("blog-large",800,400,false);
 add_image_size("blog-small",300,200,true);
 
 //register sidebar
 function my_sidebar()
 {
	 register_sidebar(
	 array(
	 'name' => 'page sidebar',
	 'id' => 'page-sidebar',
	 'before_title' => '<h4 class="widget-title">',
	 'after_title' => '</h4>'
	 )
	 );
	 
	 
	 
	 	 register_sidebar(
	 array(
	 'name' => 'blog sidebar',
	 'id' => 'blog-sidebar',
	 'before_title' => '<h4 class="widget-title">',
	 'after_title' => '</h4>'
	 )
	 );
	 
 }
 add_action("widgets_init","my_sidebar");
 
 
 
 function custom_post_type()
 {
	 $args = array(
	 "labels" => array(
	 "name" => "Cars",
	 "singular_name" => "car",
	 ),
	 "hierarchical" => true,
	 "public" => true,
	 "has_archive" => true,
	 "menu_icon" => "dashicons-car",
	 "supports" => array("title","editor","thumbnail"),
	 //"rewrite" => array("slug" => "my-car"),
	 );
	 register_post_type("cars",$args);
 }
 add_action("init","custom_post_type");
 
 function custom_post_taxonomy()
 {
	 $args = array(
	 
	 "labels" => array(
	 "name" => "Brands",
	 "singular_name" => "Brand",
	 ),
	 
	 "public" => true,
	 "hierarchical" => true,
	 );
	 register_taxonomy("brands",array("car"),$args);
 }
 add_action("init","custom_post_taxonomy");
 
 
 
 
 //woocommerce setup code
 function custom_theme_setup() {
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'custom_theme_setup' );
 //
 ?>
 
 
 