 <?php get_header(); ?>



<div class = "wrap">

<?php
if(is_active_sidebar("page-sidebar")):
?>
<?php dynamic_sidebar("page-sidebar");?>
<?php endif;?> 


<h1 id = "page_title"><?php the_title();?></h1>
<?php get_template_part("include/section","content");?>
</div>
<?php get_footer();?> 