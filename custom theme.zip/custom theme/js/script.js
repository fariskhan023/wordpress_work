
function checkwindow()
{
	if(document.documentElement.scrollTop > 100)
	{
		
		document.getElementById("scrollup").style.display = "block";
	}
	else
	{
		document.getElementById("scrollup").style.display = "none";
	}
}
window.onscroll = function()
{
	checkwindow();
		
}

function scrolltotop()
{
	
	document.documentElement.scrollTop = 0;
} 

