 <?php get_header(); ?>

<div class="wrap blog_wrap">


<?php get_template_part("include/section","archive");?>


    <div class="pagination">
	<?php previous_posts_link();?>
	<?php next_posts_link();?>  
    </div>

</div>
<?php get_footer();?> 